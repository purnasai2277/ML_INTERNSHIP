import React from "react";
import "./styles.css";
const DashboardTable = () => {
  const numRows = 14;
  const numCols = 7;
  const rowHeadings = [
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
  ];
  const colHeadings = [
    "Column A",
    "Column B",
    "Column C",
    "Column D",
    "Column E",
    "Column F",
    "Column G",
  ];
  const headings = colHeadings.map((heading, index) => (
    <th key={index}>{heading}</th>
  ));
  const rows = [];
  for (let i = 0; i < numRows; i++) {
    const cells = [];
    for (let j = 0; j < numCols; j++) {
      cells.push(<td key={j}></td>);
    }
    rows.push(
      <tr key={i}>
        <th>{rowHeadings[i]}</th>
        {cells}
      </tr>,
    );
  }
  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        State Street Components Health Status
      </header>
      <div className="dashboard-table-container">
        <table className="dashboard-table">
          <thead>
            <tr>
              <th></th>
              {headings}
            </tr>
          </thead>
          <tbody>{rows}</tbody>
        </table>
      </div>
    </div>
  );
};
export default DashboardTable;
