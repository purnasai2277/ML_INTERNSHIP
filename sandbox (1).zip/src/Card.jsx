// Card.js
import React from 'react';

function Card({ id, title, onClick }) {
  return (
    <td>
      <div className="card" onClick={() => onClick(id)}>
        {title}
      </div>
    </td>
  );
}

export default Card;
