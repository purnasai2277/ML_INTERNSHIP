// App.js
import React, { useState } from 'react';
import CardGrid from './cardgrid';

function App() {
  const [selectedCard, setSelectedCard] = useState(null);

  const handleCardClick = (id) => {
    setSelectedCard(id);
  };

  const renderDetails = () => {
    if (selectedCard !== null) {
      return <div>Details for Card {selectedCard}</div>;
    }
  };

  return (
    <div>
      <CardGrid onCardClick={handleCardClick} />
      {renderDetails()}
    </div>
  );
}

export default App;
