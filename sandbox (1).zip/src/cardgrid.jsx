// CardGrid.js
import React from 'react';
import Card from './Card';

function CardGrid({ onCardClick }) {
  const cardData = [
    { id: 1, title: 'Card 1' },
    { id: 2, title: 'Card 2' },
    { id: 3, title: 'Card 3' },
    { id: 4, title: 'Card 4' },
    { id: 5, title: 'Card 5' },
    { id: 6, title: 'Card 6' },
    { id: 7, title: 'Card 7' },
    { id: 8, title: 'Card 8' },
    { id: 9, title: 'Card 9' },
    { id: 10, title: 'Card 10' },
    { id: 11, title: 'Card 11' },
    { id: 12, title: 'Card 12' },
    { id: 13, title: 'Card 13' },
    { id: 14, title: 'Card 14' },
    { id: 15, title: 'Card 15' },
    { id: 16, title: 'Card 16' },
    { id: 17, title: 'Card 17' },
    { id: 18, title: 'Card 18' },
  ];

  const renderCard = (card) => {
    return <Card key={card.id} id={card.id} title={card.title} onClick={onCardClick} />;
  };

  const splitIntoRows = (data, rowSize) => {
    const rows = [];
    for (let i = 0; i < data.length; i += rowSize) {
      rows.push(data.slice(i, i + rowSize));
    }
    return rows;
  };

  const rows = splitIntoRows(cardData, 6);

  return (
    <table>
      <tbody>
        {rows.map((row, rowIndex) => (
          <tr key={rowIndex}>
            {row.map(renderCard)}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default CardGrid;
